package com.example.secure_exam_platform

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
