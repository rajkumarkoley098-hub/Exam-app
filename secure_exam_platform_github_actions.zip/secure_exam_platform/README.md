# Secure Exam Platform

Flutter 3.x / Dart 3.x Android-first examination management demo.

## Demo credentials

- Teacher: `teacher@exam.com` / `admin123`
- Student: `student@exam.com` / `student123`

## Run

```bash
flutter pub get
flutter run
```

## Architecture

- `lib/models/` — domain models
- `lib/services/` — mock DB, authentication, app state
- `lib/screens/auth/` — login/registration
- `lib/screens/teacher/` — exam creation, MCQs, submissions
- `lib/screens/student/` — dashboard, secure test viewport, scorecards

## Security notes

The exam screen calls `ScreenProtector.preventScreenshotOn()` and
`protectDataLeakageOn()` and disables them after submission/exit.

Android screenshot/screen-recording protection is OS-level best effort.
`FLAG_SECURE` can also hide the activity in the recent-apps preview.
No client-only anti-cheat mechanism is absolute: rooted/modified devices,
external cameras, accessibility abuse, or OS/vendor behavior can bypass
some controls.

The lifecycle observer warns when the app becomes inactive/paused. Flutter
does not expose a universal, reliable "split-screen detected" boolean, so
production proctoring should add native Android lifecycle/window callbacks
and server-side event logging.

The timer stores an absolute deadline in SharedPreferences so rebuilds do
not reset it. A production exam must use a server-authoritative start/deadline
and submit to a backend; this demo's database is in memory.

## Important dependency note

This project uses `screen_protector: ^1.5.3` rather than `^1.4.1`.
The current package documentation warns about crashes in 1.4.4–1.4.13 and
recommends 1.4.3 or earlier, or 1.5.1+.
