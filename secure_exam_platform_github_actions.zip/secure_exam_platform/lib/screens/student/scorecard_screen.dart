import 'package:flutter/material.dart';
import '../../models/exam.dart';
import '../../models/submission.dart';
import '../../services/app_controller.dart';

class ScorecardScreen extends StatelessWidget {
  final AppController controller;
  final Exam exam;
  final Submission submission;

  const ScorecardScreen({
    super.key,
    required this.controller,
    required this.exam,
    required this.submission,
  });

  @override
  Widget build(BuildContext context) {
    final base = controller.database.grade(exam, submission.answers);
    final total = base + submission.bonusPoints;

    return Scaffold(
      appBar: AppBar(title: const Text('Scorecard')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Text(exam.title, style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 16),
                  Text('$total / ${exam.totalMarks}', style: Theme.of(context).textTheme.displaySmall),
                  Text('Base: $base • Bonus: ${submission.bonusPoints}'),
                  const SizedBox(height: 8),
                  Text('Completed in ${submission.completionTime.inMinutes} minutes'),
                  if (submission.remarks.isNotEmpty) ...[
                    const Divider(height: 28),
                    Text('Teacher remark: ${submission.remarks}'),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          ...exam.questions.map((q) {
            final answerId = submission.answers[q.id];
            final selected = q.options.where((o) => o.id == answerId).map((o) => o.text).firstOrNull ?? 'Unanswered';
            final correct = selected == q.correctOption.text;
            return Card(
              child: ListTile(
                title: Text(q.text),
                subtitle: Text('Your answer: $selected\nCorrect answer: ${q.correctOption.text}'),
                leading: Icon(correct ? Icons.check_circle : Icons.cancel),
              ),
            );
          }),
        ],
      ),
    );
  }
}
