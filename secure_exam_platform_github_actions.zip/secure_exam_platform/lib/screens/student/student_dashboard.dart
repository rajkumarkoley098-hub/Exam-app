import 'package:flutter/material.dart';
import '../../models/exam.dart';
import '../../services/app_controller.dart';
import '../auth/login_screen.dart';
import 'secure_exam_screen.dart';
import 'scorecard_screen.dart';

class StudentDashboard extends StatefulWidget {
  final AppController controller;
  const StudentDashboard({super.key, required this.controller});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  @override
  Widget build(BuildContext context) {
    final db = widget.controller.database;
    final exams = db.exams.where((e) => e.status == ExamStatus.published).toList();
    final results = db.submissionsForStudent(widget.controller.currentUser!.id)
        .where((s) => s.resultsPublished)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Dashboard'),
        actions: [
          IconButton(
            onPressed: () async {
              await widget.controller.logout();
              if (!mounted) return;
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => LoginScreen(controller: widget.controller)), (_) => false);
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Active exams', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 10),
          ...exams.map((exam) => Card(
            child: ListTile(
              title: Text(exam.title),
              subtitle: Text('${exam.subject} • ${exam.durationMinutes} min • ${exam.questions.length} questions'),
              trailing: FilledButton(
                onPressed: exam.questions.isEmpty ? null : () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => SecureExamScreen(controller: widget.controller, exam: exam)));
                  setState(() {});
                },
                child: const Text('Start'),
              ),
            ),
          )),
          const SizedBox(height: 24),
          Text('Released scorecards', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 10),
          if (results.isEmpty) const Text('No released results yet.'),
          ...results.map((s) {
            final exam = db.examById(s.examId);
            final score = db.grade(exam, s.answers) + s.bonusPoints;
            return Card(
              child: ListTile(
                title: Text(exam.title),
                subtitle: Text('Score: $score/${exam.totalMarks}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ScorecardScreen(controller: widget.controller, exam: exam, submission: s))),
              ),
            );
          }),
        ],
      ),
    );
  }
}
