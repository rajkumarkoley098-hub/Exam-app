import 'dart:async';
import 'package:flutter/material.dart';
import 'package:screen_protector/screen_protector.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/exam.dart';
import '../../models/submission.dart';
import '../../services/app_controller.dart';
import '../auth/login_screen.dart';

class SecureExamScreen extends StatefulWidget {
  final AppController controller;
  final Exam exam;
  const SecureExamScreen({super.key, required this.controller, required this.exam});

  @override
  State<SecureExamScreen> createState() => _SecureExamScreenState();
}

class _SecureExamScreenState extends State<SecureExamScreen> with WidgetsBindingObserver {
  late final DateTime startedAt;
  late DateTime deadline;
  Timer? timer;
  int remainingSeconds = 0;
  int currentIndex = 0;
  final Map<String, String> answers = {};
  bool submitting = false;
  bool lifecycleDialogOpen = false;

  String get sessionKey => 'exam_deadline_${widget.exam.id}_${widget.controller.currentUser!.id}';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    startedAt = DateTime.now();
    _enableProtection();
    _restoreOrStartTimer();
  }

  Future<void> _enableProtection() async {
    await ScreenProtector.preventScreenshotOn();
    await ScreenProtector.protectDataLeakageOn();
  }

  Future<void> _disableProtection() async {
    await ScreenProtector.preventScreenshotOff();
    await ScreenProtector.protectDataLeakageOff();
  }

  Future<void> _restoreOrStartTimer() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getInt(sessionKey);
    deadline = stored == null
        ? DateTime.now().add(Duration(minutes: widget.exam.durationMinutes))
        : DateTime.fromMillisecondsSinceEpoch(stored);

    await prefs.setInt(sessionKey, deadline.millisecondsSinceEpoch);
    _tick();
    timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _tick() {
    if (!mounted) return;
    final seconds = deadline.difference(DateTime.now()).inSeconds;
    setState(() => remainingSeconds = seconds.clamp(0, 1 << 30));
    if (seconds <= 0 && !submitting) {
      _submit(auto: true);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!mounted || submitting) return;
    if ((state == AppLifecycleState.inactive || state == AppLifecycleState.paused) && !lifecycleDialogOpen) {
      _showLifecycleWarning();
    }
  }

  Future<void> _showLifecycleWarning() async {
    lifecycleDialogOpen = true;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Exam focus warning'),
        content: const Text('The exam app lost focus. Please return to the exam. Leaving the secure viewport may be recorded by a production server-side proctoring system.'),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Return to exam')),
        ],
      ),
    );
    lifecycleDialogOpen = false;
  }

  String _formatTime(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  Future<void> _submit({required bool auto}) async {
    if (submitting) return;
    if (!auto) {
      final unanswered = widget.exam.questions.length - answers.length;
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Submit exam?'),
          content: Text(unanswered > 0
              ? '$unanswered question(s) are unanswered. Submit anyway?'
              : 'All questions are answered. Submit now?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Submit')),
          ],
        ),
      );
      if (confirmed != true) return;
    }

    setState(() => submitting = true);
    timer?.cancel();

    final submission = widget.controller.database.createSubmission(
      exam: widget.exam,
      studentId: widget.controller.currentUser!.id,
      startedAt: startedAt,
      submittedAt: DateTime.now(),
      answers: answers,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(sessionKey);

    await widget.controller.auth.clearSession();
    widget.controller.currentUser = null;
    await _disableProtection();

    if (!mounted) return;
    final score = widget.controller.database.grade(widget.exam, submission.answers);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(auto ? 'Time expired. Exam auto-submitted. Score: $score/${widget.exam.totalMarks}' : 'Exam submitted. Score: $score/${widget.exam.totalMarks}')),
    );

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => LoginScreen(controller: widget.controller)),
      (_) => false,
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    _disableProtection();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.exam.questions[currentIndex];
    final warning = remainingSeconds <= 120;

    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(_formatTime(remainingSeconds), style: TextStyle(
            fontWeight: FontWeight.bold,
            color: warning ? Theme.of(context).colorScheme.error : null,
          )),
          actions: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Center(child: Text('${currentIndex + 1}/${widget.exam.questions.length}')),
            ),
          ],
        ),
        body: Column(
          children: [
            LinearProgressIndicator(value: widget.exam.questions.isEmpty ? 0 : (currentIndex + 1) / widget.exam.questions.length),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 6,
                children: [
                  Chip(label: Text('Answered ${answers.length}')),
                  Chip(label: Text('Unanswered ${widget.exam.questions.length - answers.length}')),
                  if (warning) const Chip(label: Text('⚠ Under 2 min')),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  Text('Question ${currentIndex + 1}', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(q.text, style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 20),
                  ...q.options.map((o) => Card(
                    child: RadioListTile<String>(
                      value: o.id,
                      groupValue: answers[q.id],
                      onChanged: submitting ? null : (v) => setState(() => answers[q.id] = v!),
                      title: Text(o.text),
                    ),
                  )),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: currentIndex == 0 ? null : () => setState(() => currentIndex--),
                    icon: const Icon(Icons.chevron_left),
                    label: const Text('Previous'),
                  ),
                  const Spacer(),
                  if (currentIndex < widget.exam.questions.length - 1)
                    FilledButton.icon(
                      onPressed: () => setState(() => currentIndex++),
                      icon: const Icon(Icons.chevron_right),
                      label: const Text('Next'),
                    )
                  else
                    FilledButton.icon(
                      onPressed: submitting ? null : () => _submit(auto: false),
                      icon: const Icon(Icons.send),
                      label: const Text('Submit Exam'),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
