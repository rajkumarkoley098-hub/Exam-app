import 'package:flutter/material.dart';
import '../../models/exam.dart';
import '../../models/submission.dart';
import '../../services/app_controller.dart';

class SubmissionEvaluator extends StatefulWidget {
  final AppController controller;
  final Exam exam;
  const SubmissionEvaluator({super.key, required this.controller, required this.exam});

  @override
  State<SubmissionEvaluator> createState() => _SubmissionEvaluatorState();
}

class _SubmissionEvaluatorState extends State<SubmissionEvaluator> {
  int score(Submission s) => widget.controller.database.grade(widget.exam, s.answers);

  @override
  Widget build(BuildContext context) {
    final submissions = widget.controller.database.submissionsForExam(widget.exam.id);
    return Scaffold(
      appBar: AppBar(title: const Text('Submission Evaluator')),
      body: submissions.isEmpty
          ? const Center(child: Text('No submissions yet.'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: submissions.length,
              itemBuilder: (_, i) {
                final s = submissions[i];
                final base = score(s);
                final finalScore = base + s.bonusPoints;
                return Card(
                  child: ExpansionTile(
                    title: Text('Student: ${s.studentId}'),
                    subtitle: Text('Score: $finalScore/${widget.exam.totalMarks} • ${s.completionTime.inMinutes}m'),
                    trailing: Switch(
                      value: s.resultsPublished,
                      onChanged: (v) {
                        widget.controller.database.updateSubmission(s.id, publish: v);
                        setState(() {});
                      },
                    ),
                    children: [
                      ...widget.exam.questions.map((q) {
                        final answerId = s.answers[q.id];
                        final answer = q.options.where((o) => o.id == answerId).map((o) => o.text).firstOrNull ?? 'Unanswered';
                        return ListTile(
                          title: Text(q.text),
                          subtitle: Text('Answer: $answer\nCorrect: ${q.correctOption.text}'),
                        );
                      }),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                initialValue: s.bonusPoints.toString(),
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(labelText: 'Bonus points'),
                                onFieldSubmitted: (v) {
                                  widget.controller.database.updateSubmission(s.id, bonus: double.tryParse(v) ?? 0);
                                  setState(() {});
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: TextFormField(
                                initialValue: s.remarks,
                                decoration: const InputDecoration(labelText: 'Remarks'),
                                onFieldSubmitted: (v) {
                                  widget.controller.database.updateSubmission(s.id, remarks: v);
                                  setState(() {});
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
