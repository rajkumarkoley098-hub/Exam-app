import 'package:flutter/material.dart';
import '../../models/exam.dart';
import '../../services/app_controller.dart';
import 'question_builder.dart';

class ExamCreator extends StatefulWidget {
  final AppController controller;
  const ExamCreator({super.key, required this.controller});

  @override
  State<ExamCreator> createState() => _ExamCreatorState();
}

class _ExamCreatorState extends State<ExamCreator> {
  final title = TextEditingController();
  final subject = TextEditingController();
  final duration = TextEditingController(text: '30');
  final marks = TextEditingController(text: '10');
  late final String examId;

  @override
  void initState() {
    super.initState();
    examId = 'exam-${DateTime.now().microsecondsSinceEpoch}';
  }

  void _create() {
    if (title.text.trim().isEmpty || subject.text.trim().isEmpty) return;
    final exam = Exam(
      id: examId,
      title: title.text.trim(),
      subject: subject.text.trim(),
      durationMinutes: int.tryParse(duration.text) ?? 30,
      totalMarks: int.tryParse(marks.text) ?? 10,
      status: ExamStatus.draft,
      questions: [],
    );
    widget.controller.database.addExam(exam);
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => QuestionBuilder(controller: widget.controller, exam: exam)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Exam')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Exam title')),
          const SizedBox(height: 12),
          TextField(controller: subject, decoration: const InputDecoration(labelText: 'Subject')),
          const SizedBox(height: 12),
          TextField(controller: duration, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Duration (minutes)')),
          const SizedBox(height: 12),
          TextField(controller: marks, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Total marks')),
          const SizedBox(height: 24),
          FilledButton.icon(onPressed: _create, icon: const Icon(Icons.arrow_forward), label: const Text('Create & Add Questions')),
        ],
      ),
    );
  }
}
