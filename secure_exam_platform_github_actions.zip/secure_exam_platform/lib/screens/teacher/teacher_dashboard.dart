import 'package:flutter/material.dart';
import '../../models/exam.dart';
import '../../services/app_controller.dart';
import '../auth/login_screen.dart';
import 'exam_creator.dart';
import 'submission_evaluator.dart';

class TeacherDashboard extends StatefulWidget {
  final AppController controller;
  const TeacherDashboard({super.key, required this.controller});

  @override
  State<TeacherDashboard> createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  @override
  Widget build(BuildContext context) {
    final exams = widget.controller.database.exams;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Dashboard'),
        actions: [
          IconButton(
            onPressed: () async {
              await widget.controller.logout();
              if (!mounted) return;
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => LoginScreen(controller: widget.controller)), (_) => false);
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => ExamCreator(controller: widget.controller)));
          setState(() {});
        },
        icon: const Icon(Icons.add),
        label: const Text('New Exam'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Examinations', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...exams.map((exam) => Card(
            child: ListTile(
              title: Text(exam.title),
              subtitle: Text('${exam.subject} • ${exam.durationMinutes} min • ${exam.questions.length} questions'),
              leading: CircleAvatar(child: Text(exam.questions.length.toString())),
              trailing: PopupMenuButton<String>(
                onSelected: (v) async {
                  if (v == 'toggle') {
                    widget.controller.database.publishExam(exam.id, exam.status == ExamStatus.draft);
                    setState(() {});
                  } else if (v == 'submissions') {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => SubmissionEvaluator(controller: widget.controller, exam: exam)));
                    setState(() {});
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'toggle', child: Text(exam.status == ExamStatus.draft ? 'Publish' : 'Unpublish')),
                  const PopupMenuItem(value: 'submissions', child: Text('View submissions')),
                ],
              ),
            ),
          )),
        ],
      ),
    );
  }
}
