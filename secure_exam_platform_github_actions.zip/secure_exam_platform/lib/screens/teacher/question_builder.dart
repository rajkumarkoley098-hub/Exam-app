import 'package:flutter/material.dart';
import '../../models/exam.dart';
import '../../models/question.dart';
import '../../models/option.dart';
import '../../services/app_controller.dart';

class QuestionBuilder extends StatefulWidget {
  final AppController controller;
  final Exam exam;
  const QuestionBuilder({super.key, required this.controller, required this.exam});

  @override
  State<QuestionBuilder> createState() => _QuestionBuilderState();
}

class _QuestionBuilderState extends State<QuestionBuilder> {
  final question = TextEditingController();
  final options = List.generate(4, (_) => TextEditingController());
  int correct = 0;

  void _add() {
    if (question.text.trim().isEmpty || options.any((x) => x.text.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fill the question and all 4 options.')));
      return;
    }
    widget.controller.database.addQuestion(
      widget.exam.id,
      ExamQuestion(
        id: 'q-${DateTime.now().microsecondsSinceEpoch}',
        text: question.text.trim(),
        options: List.generate(4, (i) => ExamOption(
          id: 'o-${DateTime.now().microsecondsSinceEpoch}-$i',
          text: options[i].text.trim(),
          isCorrect: i == correct,
        )),
      ),
    );
    question.clear();
    for (final o in options) o.clear();
    setState(() => correct = 0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Questions • ${widget.exam.title}')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ...widget.exam.questions.asMap().entries.map((entry) => Card(
            child: ListTile(
              title: Text('${entry.key + 1}. ${entry.value.text}'),
              subtitle: Text('Correct: ${entry.value.correctOption.text}'),
            ),
          )),
          const Divider(height: 32),
          Text('Add MCQ', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          TextField(controller: question, maxLines: 3, decoration: const InputDecoration(labelText: 'Question')),
          const SizedBox(height: 12),
          ...List.generate(4, (i) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              children: [
                Radio<int>(value: i, groupValue: correct, onChanged: (v) => setState(() => correct = v!)),
                Expanded(child: TextField(controller: options[i], decoration: InputDecoration(labelText: 'Option ${i + 1}'))),
              ],
            ),
          )),
          FilledButton.icon(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Add Question')),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }
}
