import 'package:flutter/material.dart';
import '../../services/app_controller.dart';
import '../../models/user.dart';
import 'register_screen.dart';
import '../student/student_dashboard.dart';
import '../teacher/teacher_dashboard.dart';

class LoginScreen extends StatefulWidget {
  final AppController controller;
  const LoginScreen({super.key, required this.controller});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(text: 'student@exam.com');
  final password = TextEditingController(text: 'student123');
  bool loading = false;
  String? error;

  Future<void> _login() async {
    setState(() { loading = true; error = null; });
    final ok = await widget.controller.login(email.text, password.text);
    if (!mounted) return;
    setState(() => loading = false);
    if (!ok) {
      setState(() => error = 'Invalid email/password.');
      return;
    }
    final user = widget.controller.currentUser!;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => user.role == UserRole.teacher
            ? TeacherDashboard(controller: widget.controller)
            : StudentDashboard(controller: widget.controller),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.lock_person, size: 64),
                    const SizedBox(height: 12),
                    Text('Secure Exam', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
                    const SizedBox(height: 8),
                    const Text('Role-based examination platform', textAlign: TextAlign.center),
                    const SizedBox(height: 28),
                    TextField(controller: email, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email))),
                    const SizedBox(height: 12),
                    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.password))),
                    if (error != null) ...[
                      const SizedBox(height: 10),
                      Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                    ],
                    const SizedBox(height: 20),
                    FilledButton(
                      onPressed: loading ? null : _login,
                      child: loading ? const CircularProgressIndicator() : const Text('Login'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => RegisterScreen(controller: widget.controller),
                      )),
                      child: const Text('Create account'),
                    ),
                    const SizedBox(height: 8),
                    const Text('Demo: teacher@exam.com / admin123\nstudent@exam.com / student123', textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
