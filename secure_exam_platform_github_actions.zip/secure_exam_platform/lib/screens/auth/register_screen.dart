import 'package:flutter/material.dart';
import '../../models/user.dart';
import '../../services/app_controller.dart';
import '../student/student_dashboard.dart';
import '../teacher/teacher_dashboard.dart';

class RegisterScreen extends StatefulWidget {
  final AppController controller;
  const RegisterScreen({super.key, required this.controller});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  UserRole role = UserRole.student;

  Future<void> _register() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) return;
    try {
      widget.controller.database.register(email.text.trim(), role);
      final user = widget.controller.database.findUser(email.text)!;
      await widget.controller.auth.saveRegisteredUser(user, password.text);
      widget.controller.currentUser = user;
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) => role == UserRole.teacher
              ? TeacherDashboard(controller: widget.controller)
              : StudentDashboard(controller: widget.controller),
        ),
        (_) => false,
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registration')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')),
            const SizedBox(height: 12),
            TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
            const SizedBox(height: 12),
            DropdownButtonFormField<UserRole>(
              value: role,
              items: UserRole.values.map((r) => DropdownMenuItem(value: r, child: Text(r == UserRole.teacher ? 'Teacher' : 'Student'))).toList(),
              onChanged: (v) => setState(() => role = v!),
              decoration: const InputDecoration(labelText: 'Role'),
            ),
            const SizedBox(height: 20),
            FilledButton(onPressed: _register, child: const Text('Register')),
          ],
        ),
      ),
    );
  }
}
