class ExamOption {
  final String id;
  final String text;
  final bool isCorrect;

  const ExamOption({
    required this.id,
    required this.text,
    required this.isCorrect,
  });

  ExamOption copyWith({String? text, bool? isCorrect}) => ExamOption(
        id: id,
        text: text ?? this.text,
        isCorrect: isCorrect ?? this.isCorrect,
      );
}
