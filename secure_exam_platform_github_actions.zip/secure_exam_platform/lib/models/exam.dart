import 'question.dart';

enum ExamStatus { draft, published }

class Exam {
  final String id;
  String title;
  String subject;
  int durationMinutes;
  int totalMarks;
  ExamStatus status;
  final List<ExamQuestion> questions;

  Exam({
    required this.id,
    required this.title,
    required this.subject,
    required this.durationMinutes,
    required this.totalMarks,
    required this.status,
    required this.questions,
  });
}
