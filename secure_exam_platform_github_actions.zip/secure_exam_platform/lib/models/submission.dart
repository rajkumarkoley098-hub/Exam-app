class Submission {
  final String id;
  final String examId;
  final String studentId;
  final DateTime startedAt;
  final DateTime submittedAt;
  final Map<String, String> answers;
  double bonusPoints;
  String remarks;
  bool resultsPublished;

  Submission({
    required this.id,
    required this.examId,
    required this.studentId,
    required this.startedAt,
    required this.submittedAt,
    required this.answers,
    this.bonusPoints = 0,
    this.remarks = '',
    this.resultsPublished = false,
  });

  Duration get completionTime => submittedAt.difference(startedAt);
}
