enum UserRole { teacher, student }

extension UserRoleX on UserRole {
  String get value => name.toUpperCase();

  static UserRole fromString(String value) {
    return value.toUpperCase() == 'TEACHER'
        ? UserRole.teacher
        : UserRole.student;
  }
}

class AppUser {
  final String id;
  final String email;
  final UserRole role;

  const AppUser({
    required this.id,
    required this.email,
    required this.role,
  });
}
