import 'option.dart';

class ExamQuestion {
  final String id;
  final String text;
  final List<ExamOption> options;

  const ExamQuestion({
    required this.id,
    required this.text,
    required this.options,
  });

  ExamOption get correctOption =>
      options.firstWhere((o) => o.isCorrect);
}
