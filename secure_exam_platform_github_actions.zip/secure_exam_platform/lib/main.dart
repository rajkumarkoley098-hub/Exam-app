import 'package:flutter/material.dart';
import 'services/app_controller.dart';
import 'models/user.dart';
import 'screens/auth/login_screen.dart';
import 'screens/student/student_dashboard.dart';
import 'screens/teacher/teacher_dashboard.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = AppController();
  await controller.initialize();
  runApp(SecureExamApp(controller: controller));
}

class SecureExamApp extends StatelessWidget {
  final AppController controller;
  const SecureExamApp({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Secure Exam',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      home: controller.currentUser == null
          ? LoginScreen(controller: controller)
          : controller.currentUser!.role == UserRole.teacher
              ? TeacherDashboard(controller: controller)
              : StudentDashboard(controller: controller),
    );
  }
}
