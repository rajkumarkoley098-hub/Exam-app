import 'package:flutter/foundation.dart';
import '../models/exam.dart';
import '../models/question.dart';
import '../models/option.dart';
import '../models/submission.dart';
import '../models/user.dart';

class MockDatabase extends ChangeNotifier {
  final List<AppUser> users = [
    const AppUser(id: 'teacher-1', email: 'teacher@exam.com', role: UserRole.teacher),
    const AppUser(id: 'student-1', email: 'student@exam.com', role: UserRole.student),
  ];

  final List<Exam> exams = [];
  final List<Submission> submissions = [];

  MockDatabase() {
    _seed();
  }

  void _seed() {
    exams.add(
      Exam(
        id: 'exam-demo',
        title: 'General Science Demo',
        subject: 'Science',
        durationMinutes: 10,
        totalMarks: 5,
        status: ExamStatus.published,
        questions: [
          ExamQuestion(
            id: 'q1',
            text: 'Which planet is known as the Red Planet?',
            options: [
              const ExamOption(id: 'q1o1', text: 'Earth', isCorrect: false),
              const ExamOption(id: 'q1o2', text: 'Mars', isCorrect: true),
              const ExamOption(id: 'q1o3', text: 'Venus', isCorrect: false),
              const ExamOption(id: 'q1o4', text: 'Jupiter', isCorrect: false),
            ],
          ),
          ExamQuestion(
            id: 'q2',
            text: 'What is H2O commonly called?',
            options: [
              const ExamOption(id: 'q2o1', text: 'Oxygen', isCorrect: false),
              const ExamOption(id: 'q2o2', text: 'Hydrogen', isCorrect: false),
              const ExamOption(id: 'q2o3', text: 'Water', isCorrect: true),
              const ExamOption(id: 'q2o4', text: 'Salt', isCorrect: false),
            ],
          ),
          ExamQuestion(
            id: 'q3',
            text: 'How many sides does a triangle have?',
            options: [
              const ExamOption(id: 'q3o1', text: '2', isCorrect: false),
              const ExamOption(id: 'q3o2', text: '3', isCorrect: true),
              const ExamOption(id: 'q3o3', text: '4', isCorrect: false),
              const ExamOption(id: 'q3o4', text: '5', isCorrect: false),
            ],
          ),
        ],
      ),
    );
  }

  AppUser? findUser(String email) {
    for (final user in users) {
      if (user.email.toLowerCase() == email.trim().toLowerCase()) return user;
    }
    return null;
  }

  void register(String email, UserRole role) {
    if (findUser(email) != null) throw Exception('Email already registered.');
    users.add(AppUser(
      id: 'user-${DateTime.now().microsecondsSinceEpoch}',
      email: email.trim(),
      role: role,
    ));
    notifyListeners();
  }

  void addExam(Exam exam) {
    exams.add(exam);
    notifyListeners();
  }

  void publishExam(String id, bool publish) {
    final exam = exams.firstWhere((e) => e.id == id);
    exam.status = publish ? ExamStatus.published : ExamStatus.draft;
    notifyListeners();
  }

  void addQuestion(String examId, ExamQuestion question) {
    final exam = exams.firstWhere((e) => e.id == examId);
    exam.questions.add(question);
    notifyListeners();
  }

  int grade(Exam exam, Map<String, String> answers) {
    var score = 0;
    for (final q in exam.questions) {
      if (answers[q.id] == q.correctOption.id) score++;
    }
    return score;
  }

  Submission createSubmission({
    required Exam exam,
    required String studentId,
    required DateTime startedAt,
    required DateTime submittedAt,
    required Map<String, String> answers,
  }) {
    final submission = Submission(
      id: 'submission-${DateTime.now().microsecondsSinceEpoch}',
      examId: exam.id,
      studentId: studentId,
      startedAt: startedAt,
      submittedAt: submittedAt,
      answers: Map<String, String>.from(answers),
    );
    submissions.add(submission);
    notifyListeners();
    return submission;
  }

  List<Submission> submissionsForExam(String examId) =>
      submissions.where((s) => s.examId == examId).toList();

  List<Submission> submissionsForStudent(String studentId) =>
      submissions.where((s) => s.studentId == studentId).toList();

  Exam examById(String id) => exams.firstWhere((e) => e.id == id);

  void updateSubmission(String id, {double? bonus, String? remarks, bool? publish}) {
    final s = submissions.firstWhere((x) => x.id == id);
    if (bonus != null) s.bonusPoints = bonus;
    if (remarks != null) s.remarks = remarks;
    if (publish != null) s.resultsPublished = publish;
    notifyListeners();
  }
}
