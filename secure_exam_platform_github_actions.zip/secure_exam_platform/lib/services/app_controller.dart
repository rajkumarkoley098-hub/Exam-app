import 'package:flutter/material.dart';
import '../models/user.dart';
import 'auth_service.dart';
import 'mock_database.dart';

class AppController extends ChangeNotifier {
  final MockDatabase database = MockDatabase();
  late final AuthService auth = AuthService(database);

  AppUser? currentUser;
  bool ready = false;

  Future<void> initialize() async {
    currentUser = await auth.currentUser();
    ready = true;
    notifyListeners();
  }

  Future<bool> login(String email, String password) async {
    final user = await auth.login(email, password);
    if (user == null) return false;
    currentUser = user;
    notifyListeners();
    return true;
  }

  Future<void> logout() async {
    await auth.clearSession();
    currentUser = null;
    notifyListeners();
  }
}
