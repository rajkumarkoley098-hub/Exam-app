import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import 'mock_database.dart';

class AuthService {
  static const _emailKey = 'auth_email';
  static const _roleKey = 'auth_role';
  static const _idKey = 'auth_id';

  final MockDatabase db;

  AuthService(this.db);

  Future<AppUser?> login(String email, String password) async {
    final valid = (email == 'teacher@exam.com' && password == 'admin123') ||
        (email == 'student@exam.com' && password == 'student123');
    if (!valid) return null;

    final user = db.findUser(email);
    if (user == null) return null;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_emailKey, user.email);
    await prefs.setString(_roleKey, user.role.value);
    await prefs.setString(_idKey, user.id);
    return user;
  }

  Future<void> saveRegisteredUser(AppUser user, String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_emailKey, user.email);
    await prefs.setString(_roleKey, user.role.value);
    await prefs.setString(_idKey, user.id);
  }

  Future<AppUser?> currentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString(_emailKey);
    final role = prefs.getString(_roleKey);
    final id = prefs.getString(_idKey);
    if (email == null || role == null || id == null) return null;
    return AppUser(id: id, email: email, role: UserRoleX.fromString(role));
  }

  Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
