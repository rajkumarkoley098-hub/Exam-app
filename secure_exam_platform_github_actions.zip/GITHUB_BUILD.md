# Build the APK on GitHub

1. Create a GitHub repository and upload this project.
2. Open **Actions** → **Build Android APK** → **Run workflow**.
3. Wait for the workflow to finish.
4. Open the completed workflow run.
5. Under **Artifacts**, download **secure-exam-release-apk**.
6. Extract the ZIP and install `app-release.apk` on Android.

The workflow runs `flutter pub get`, `flutter analyze`, and `flutter build apk --release`, then uploads the APK as a downloadable GitHub Actions artifact.
